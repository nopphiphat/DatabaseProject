
//It is the link of resouces
global.constants = {
    website:"",
    mainsite:"",
    login_status=false,
    username:'',
    password:'',
};