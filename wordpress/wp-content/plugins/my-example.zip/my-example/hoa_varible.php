<?php
$hoa_test=$_POST["hoa_request_form"];
$hoa_address=$hoa_test["hoa_c_address"];
echo $hoa_address;
?>