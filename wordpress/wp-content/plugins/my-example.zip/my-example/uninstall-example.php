<?php

    //if(!defined('name'))
    //exit();

    //delete_option('');
    //delet tables in database
?>